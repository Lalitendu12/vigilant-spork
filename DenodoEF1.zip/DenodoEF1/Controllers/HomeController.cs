﻿using DenodoEF1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DenodoEF1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        //  DenodoDbContext _context;
        //public HomeController()
        //{
        //    _context = new DenodoDbContext();

        //}
        DenodoDbContext denodoDbContext = new DenodoDbContext();
        public ActionResult Index()
        {
            try
            {
                //var data = denodoDbContext.Products.ToList();
                //return View("ConnectionSuccess");

                var status=denodoDbContext.Database.Exists();
                if(status==true)
                    return View("ConnectionSuccess");
                else
                    return View("NoDB");

            }
            catch (Exception ex)
            {
                return View("ConnectionFailed");
            }
        }
    }
}
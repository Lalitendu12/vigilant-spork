﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace DenodoEF1.Models
{
    public class DenodoDbContext: DbContext
    {
  

       // public virtual DbSet<Product> Products { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;


namespace EntityFrameworkSample
{
    //class InternetInc
    //{
    //    public InternetInc()
    //    {
    //    }

    //    [Key]
    //    public long IInc_Id { get; set; }
    //    public string Summary { get; set; }
    //    public DateTime TTime { get; set; }
    //    public String TaxId { get; set; }
    //    public string Specific_Field1 { get; set; }
    //    public string Specific_Field2 { get; set; }
    //}
}

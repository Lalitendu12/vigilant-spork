﻿using System;
using System.Data;
using System.Data.Odbc;
using System.Data.Common;
using Npgsql;


namespace Denodo
{
    class ADONetSample
    {
        static int maxRows = 100;

        static void Main(string[] args)
        {
            foreach (string arg in args)
            {
                Console.WriteLine("arg:" + arg);
            }

            if (args.Length == 7 && args[0].Equals("npgsql"))
            {
                string host = args[1];
                string port = args[2];
                string db = args[3];
                string user = args[4];
                string password = args[5];
                string query = args[6];

                string connectionString = "Server=" + host +
                                          ";Port=" + port +
                                          ";User Id=" + user +
                                          ";Password=" + password +
                                          ";Database=" + db;

                using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        HandleReader(command, maxRows);
                    }
                }
            }
            else if (args.Length == 3 && args[0].Equals("odbc"))
            {
                string dsn = args[1];
                string query = args[2];

                using (OdbcConnection connection = new OdbcConnection("DSN=" + dsn))
                {
                    connection.Open();
                    using (OdbcCommand command = connection.CreateCommand())
                    {
                        command.CommandText = query;
                        HandleReader(command, maxRows);
                    }
                }
                
            }
            else
            {
                Console.WriteLine("usage: vdp-clients-ADO.NET npgsql {host} {port} {database} {username} {passwd} {query}");
                Console.WriteLine("       or");
                Console.WriteLine("       vdp-clients-ADO.NET odbc {dsn} {query}");
                Console.WriteLine("example: vdp_clients_ado.net npgsql localhost 9996 foodb foouser foopasswd \"select 1 from dual()\"");
                Console.WriteLine("example: vdp_clients_ado.net odbc VDP_DSN \"select 1 from dual()\"");
                Environment.Exit(0);
            }
        }

        static void HandleReader(DbCommand command,int maxRows)
        {
            using (DbDataReader reader = command.ExecuteReader())
            {
                int readRows = 0;
                Console.WriteLine();
                Console.WriteLine("RESULTS:");
                while (reader.Read() && readRows < maxRows)
                {
                    for (int col = 0; col < reader.FieldCount; col++)
                    {
                        Console.Write(reader.GetName(col) +"="+ reader[col]);
                        Console.Write(" ");
                    }
                    Console.WriteLine();
                    readRows++;
                }
            }
        }
    }
}

import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'app-user-detail',
    template: `
      <h3>Some user Details</h3>
    `
})
export class UserDetailComponent {
}

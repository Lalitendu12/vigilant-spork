﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;


namespace EntityFrameworkSample
{    
    class SampleContext : Context
    {
        public DbSet<InternetInc> InternetIncs { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Map to the correct Database tables
            modelBuilder.Entity<InternetInc>().ToTable("internet_inc", "public");
        }
    }
}
